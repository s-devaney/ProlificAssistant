export function openProlificStudy(id: string) {
  window.open(`https://app.prolific.co/studies/${id}`);
}
